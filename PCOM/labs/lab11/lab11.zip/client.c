#include "common.h"
#include "tea.h"
#include "utils.h"
#include "dh.h"

#include <arpa/inet.h>
#include <ctype.h>
#include <errno.h>
#include <netdb.h>
#include <netinet/in.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <sys/poll.h>
#include <sys/socket.h>
#include <sys/types.h>
#include <unistd.h>

void run_client(int sockfd) {
    int res;
    struct message msg;
    while (1) {
        char *s = fgets(msg.buffer, sizeof(msg.buffer), stdin);
        DIE(!s, "fgets");

        // Get rid of the newline character.
        msg.size = strlen(msg.buffer);
        msg.buffer[msg.size - 1] = 0;

        if (!strcmp(msg.buffer, "QUIT"))
            break;

        send_message(sockfd, &msg);

        res = recv_message(sockfd, &msg);
        if (res == 0) {
            puts("Server disconnected!");
            break;
        }

        DIE(msg.buffer[msg.size - 1] != '\0', "Non-string reply!");
        printf("Server reply: %s\n", msg.buffer);
    }
}

uint32_t *obtain_key_plain(int sockfd) {
    uint32_t *key = create_key();
    struct message msg;
    msg.size = KEY_SIZE;
    
    
    memcpy(msg.buffer, key, KEY_SIZE); // Copy the key into the buffer
    send_message(sockfd, &msg);
    return key;
}


void run_encryption_client(int sockfd) {
    int res;
    struct message msg;

    // Generate and send the key to the server
    uint32_t *key = obtain_key_plain(sockfd);

    while (1) {
        // Read a string from the user
        char *s = fgets(msg.buffer, sizeof(msg.buffer), stdin);
        DIE(!s, "fgets");

        // Get rid of the newline character
        msg.size = strlen(msg.buffer);
        msg.buffer[msg.size - 1] = 0;

        // Exit if the user inputs "QUIT"
        if (!strcmp(msg.buffer, "QUIT"))
            break;

        // Encrypt and send the message to the server
        send_encrypted(sockfd, &msg, key);

        // Receive and decrypt the server's reply
        recv_encrypted(sockfd, &msg, key);

        // Print the decrypted message
        printf("Server reply: %s\n", msg.buffer);
    }

    // Clean up
    destroy_key(key);
}

int main(int argc, char *argv[])
{
    if (argc != 3) {
        printf("\n Usage: %s <ip> <port>\n", argv[0]);
        return 1;
    }

    // Parsam port-ul ca un numar
    uint16_t port;
    int rc = sscanf(argv[2], "%hu", &port);
    DIE(rc != 1, "Given port is invalid");

    // Obtinem un socket TCP pentru conectarea la server
    int sockfd = socket(PF_INET, SOCK_STREAM, 0);
    DIE(sockfd < 0, "socket");

    // Completăm in serv_addr adresa serverului, familia de adrese si portul
    // pentru conectare
    struct sockaddr_in serv_addr;
    memset(&serv_addr, 0, sizeof(struct sockaddr_in));

    serv_addr.sin_family = AF_INET;
    serv_addr.sin_port = htons(port);
    rc = inet_pton(AF_INET, argv[1], &serv_addr.sin_addr.s_addr);
    DIE(rc <= 0, "inet_pton");

    // Ne conectăm la server
    rc = connect(sockfd, (struct sockaddr *) &serv_addr, sizeof(serv_addr));
    DIE(rc < 0, "connect");

    // Comment run_client and uncomment run_ecryption_client
    run_encryption_client(sockfd);
    /*run_client(sockfd);*/

    // Inchidem conexiunea si socketul creat
    close(sockfd);

    return 0;
}
