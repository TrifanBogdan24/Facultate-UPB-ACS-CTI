#include "common.h"
#include "tea.h"
#include "utils.h"
#include "dh.h"

#include <arpa/inet.h>
#include <errno.h>
#include <netinet/in.h>
#include <poll.h>
#include <ctype.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <sys/socket.h>
#include <sys/types.h>
#include <unistd.h>

#define MAX_CONNECTIONS 32

void process_request(char *contents)
{
    char *ptr = contents;
    while (*ptr) {
        *ptr = toupper(*ptr);
        ++ptr;
    }
}

void run_server(int sockfd) {
    int res;
    struct message msg;
    while (1) {
        res = recv_message(sockfd, &msg);
        if (res == 0) {
            puts("Client disconnected!");
            break;
        }

        DIE(msg.buffer[msg.size - 1] != '\0', "Non-string request!");
        printf("Client request: %s\n", msg.buffer);

        process_request(msg.buffer);
        send_message(sockfd, &msg);
    }
}

uint32_t *obtain_key_plain(int sockfd) {
    struct message msg;
    recv_message(sockfd, &msg);
    uint32_t *key = malloc(KEY_SIZE);
    if (key == NULL) {
        perror("malloc");
        exit(EXIT_FAILURE);
    }
    memcpy(key, msg.buffer, KEY_SIZE);
    return key;
}

void run_secure_server(int sockfd)
{
    int res;
    struct message msg;

    // Receive the key from the client
    uint32_t *key = obtain_key_plain(sockfd);

    while (1) {
        // Receive an encrypted message from the client
        recv_encrypted(sockfd, &msg, key);

        // Process the received message (e.g., convert to uppercase)
        process_request(msg.buffer);

        // Encrypt and send the processed message back to the client
        send_encrypted(sockfd, &msg, key);
    }

    // Clean up
    destroy_key(key);
}

int main(int argc, char *argv[]) {
    if (argc != 3) {
        fprintf(stderr, "Usage: %s <ip> <port>\n", argv[0]);
        return 1;
    }

    // Parsam port-ul ca un numar
    uint16_t port;
    int res = sscanf(argv[2], "%hu", &port);
    DIE(res != 1, "Given port is invalid");

    // Obtinem un socket TCP pentru receptionarea conexiunilor
    int listenfd = socket(AF_INET, SOCK_STREAM, 0);
    DIE(listenfd < 0, "socket");

    // Completăm in serv_addr adresa serverului, familia de adrese si portul
    // pentru conectare
    struct sockaddr_in serv_addr;
    socklen_t socket_len = sizeof(struct sockaddr_in);

    // Facem adresa socket-ului reutilizabila, ca sa nu primim eroare in caz ca
    // rulam de 2 ori rapid
    int enable = 1;
    res = setsockopt(listenfd, SOL_SOCKET, SO_REUSEADDR, &enable, sizeof(enable));
    DIE(res < 0, "setsockopt(SO_REUSEADDR) failed");

    memset(&serv_addr, 0, socket_len);
    serv_addr.sin_family = AF_INET;
    serv_addr.sin_addr.s_addr = INADDR_ANY;
    serv_addr.sin_port = htons(port);

    // Facem bind pe socket la adresa serverului
    res = bind(listenfd, (struct sockaddr *)&serv_addr, sizeof(serv_addr));
    DIE(res < 0, "bind");

    // Punem serverul sa asculte la socket pentru conexiuni
    res = listen(listenfd, MAX_CONNECTIONS);
    DIE(res < 0, "listen");

    // Main server loop
    while (1) {
        // Acceptam o conexiune de la un client
        struct sockaddr_in cli_addr;
        int connfd = accept(listenfd, (struct sockaddr *)&cli_addr, &socket_len);
        if (connfd < 0) {
            perror("accept");
            continue;
        }

        printf("New connection from %s:%d\n", inet_ntoa(cli_addr.sin_addr), ntohs(cli_addr.sin_port));

        // Comment run_server and uncomment run_secure_server
        run_secure_server(connfd);
        /*run_server(connfd);*/

        // Inchidem conexiunea cu clientul
        close(connfd);
    }

    // Inchidem socket-ul serverului
    close(listenfd);

    return 0;
}
