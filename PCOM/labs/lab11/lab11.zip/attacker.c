// attacker.c
#include "common.h"
#include "dh.h"
#include "tea.h"
#include "utils.h"

#include <arpa/inet.h>
#include <errno.h>
#include <netinet/in.h>
#include <poll.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <sys/socket.h>
#include <sys/types.h>
#include <unistd.h>

void intercept_and_decrypt(int sockfd) {
    struct message msg;
    uint32_t public_secret;

    // Receive Alice's public secret
    recv(sockfd, &public_secret, sizeof(public_secret), 0);

    // Modify public secret and send it to Bob
    uint32_t modified_public_secret = public_secret - 1;
    send(sockfd, &modified_public_secret, sizeof(modified_public_secret), 0);

    // Receive Bob's public secret
    recv(sockfd, &public_secret, sizeof(public_secret), 0);

    // Modify public secret and send it to Alice
    uint32_t modified_public_secret_alice = public_secret - 1;
    send(sockfd, &modified_public_secret_alice, sizeof(modified_public_secret_alice), 0);

    // Perform DH with Alice
    uint32_t shared_secret_alice = mod_pow(modified_public_secret_alice, PRIVATE, PRIME);
    uint32_t *key_alice = derive_key(shared_secret_alice);

    // Perform DH with Bob
    uint32_t shared_secret_bob = mod_pow(modified_public_secret, PRIVATE, PRIME);
    uint32_t *key_bob = derive_key(shared_secret_bob);

    while (1) {
        // Intercept and decrypt message from Alice
        int res = recv_message(sockfd, &msg);
        if (res == 0) {
            puts("Client disconnected!");
            break;
        }

        uint8_t *decrypted_data = decrypt(msg.buffer, msg.size, key_alice);
        printf("Intercepted message from Alice: %s\n", (char *)decrypted_data);
        free(decrypted_data);

        // Encrypt and forward message to Bob
        uint8_t *encrypted_data = encrypt(msg.buffer, msg.size, key_bob);
        send(sockfd, encrypted_data, msg.size, 0);
        free(encrypted_data);
    }

    free(key_alice);
    free(key_bob);
}

int main(int argc, char *argv[]) {
    int sockfd;
    struct sockaddr_in serv_addr;

    // Create socket
    sockfd = socket(AF_INET, SOCK_STREAM, 0);
    if (sockfd < 0) {
        perror("Error opening socket");
        exit(EXIT_FAILURE);
    }

    serv_addr.sin_family = AF_INET;
    serv_addr.sin_port = htons(PORT);

    // Convert IPv4 and IPv6 addresses from text to binary form
    if (inet_pton(AF_INET, "127.0.0.1", &serv_addr.sin_addr) <= 0) {
        perror("Invalid address/ Address not supported");
        exit(EXIT_FAILURE);
    }

    // Connect to server
    if (connect(sockfd, (struct sockaddr *)&serv_addr, sizeof(serv_addr)) < 0) {
        perror("Connection failed");
        exit(EXIT_FAILURE);
    }

    intercept_and_decrypt(sockfd);

    close(sockfd);

    return 0;
}
